import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { GenericModalComponent } from './modal.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
})
export class ParentComponent {
  constructor(private dialog: MatDialog) {}

  openModal() {
    const dialogRef = this.dialog.open(GenericModalComponent, {
      width: '400px',
      data: {
        title: 'Ajouter un Employé',
        fields: [
          { name: 'name', label: 'Nom', type: 'text', required: true, defaultValue: '' },
          { name: 'department', label: 'Département', type: 'text', required: true, defaultValue: '' },
        ],
        submitText: 'Ajouter',
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        console.log('Données du formulaire:', result);
        // Traitez les données soumises ici (ajouter un employé, une marque, un modèle, etc.)
      }
    });
  }
}
