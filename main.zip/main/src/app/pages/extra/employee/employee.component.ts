import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog'; 
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import {MatIconModule} from '@angular/material/icon';
import {DatePipe} from '@angular/common';
import { MaterialModule } from 'src/app/material.module';
import { PageEvent } from '@angular/material/paginator'; 
import { FormsModule } from '@angular/forms';  // Assurez-vous que FormsModule est bien importé ici


export interface Employee {
  id: number;
  name: string;
  department: string;
}

@Component({
  selector: 'app-employee',
  // standalone: true,
  templateUrl: './employee.component.html',
  imports: [MatListModule, MatCardModule, DatePipe,MatIconModule, MaterialModule, FormsModule ],
  
})
export class EmployeeComponent {
  displayedColumns: string[] = ['id', 'name', 'department', 'actions'];
  employees: any[] = [
    { id: 1, name: 'Alice Dupont', department: 'IT' },
    { id: 2, name: 'Jean Martin', department: 'HR' },
    { id: 3, name: 'Sophie Bernard', department: 'Finance' },
    { id: 4, name: 'Paul Durand', department: 'Marketing' },
    { id: 5, name: 'Nathalie Lefevre', department: 'Sales' },
    { id: 6, name: 'Louis Boulanger', department: 'Support' },
    { id: 7, name: 'Julie Leroux', department: 'Operations' },
    { id: 8, name: 'Marc Dupuis', department: 'Design' },
    { id: 9, name: 'Claire Girard', department: 'IT' },
    { id: 10, name: 'Lucas Petit', department: 'HR' },
    // Ajoutez d'autres employés si nécessaire
  ];

  paginatedEmployees: Employee[] = [];

  // Nouveau employé à ajouter
  newEmployee = { name: '', department: '' };

  // Paramètres de pagination
  pageSize = 5;
  currentPage = 0;
  pageSizeOptions = [5, 10, 20];

  constructor(private dialog: MatDialog) {}

  openModal() {
    // Utiliser MatDialog pour afficher une modale
    this.dialog.open(ModalComponent, {
      width: '400px', // Vous pouvez personnaliser la taille de la modale
    });
  }

  add() {
    this.openModal();
  }

  ngOnInit() {
    // Initialisez la pagination au chargement du composant
    this.updatePagination();
  }

  updatePagination() {
    const startIndex = this.currentPage * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    this.paginatedEmployees = this.employees.slice(startIndex, endIndex);
  }

  // Fonction pour ajouter un employé
  addEmployee() {
    if (this.newEmployee.name && this.newEmployee.department) {
      const newId = this.employees.length + 1;
      const employee = { ...this.newEmployee, id: newId };
      this.employees.push(employee);
      this.newEmployee = { name: '', department: '' }; // Réinitialiser le formulaire
    }
  }

  // Fonction d'édition d'un employé
  editEmployee(employee: any) {
    console.log('Editing employee:', employee);
  }

  // Fonction de suppression d'un employé
  deleteEmployee(employeeId: number) {
    console.log('Deleting employee with ID:', employeeId);
    this.employees = this.employees.filter(emp => emp.id !== employeeId);
  }

  // Fonction pour gérer la pagination
  onPaginateChange(event: PageEvent) {
    const { pageIndex, pageSize } = event;
    this.currentPage = pageIndex;
    this.pageSize = pageSize;

    this.updatePagination();

    // Vous pouvez ajouter ici une logique de récupération des données paginées depuis un serveur si nécessaire
    console.log('Pagination changed: ', event);
  }

}

@Component({
  selector: 'app-modal',
  template: `
  `,
})
export class ModalComponent {
  constructor(public dialog: MatDialog) {}

  close() {
    this.dialog.closeAll(); // Ferme la modale
  }
}