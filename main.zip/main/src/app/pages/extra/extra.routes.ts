import { Routes } from '@angular/router';



// pages
import { AppIconsComponent } from './icons/icons.component';
import { AppSamplePageComponent } from './sample-page/sample-page.component';
import { EmployeeComponent } from './employee/employee.component';
import { ParentComponent } from './employee/parent.component';

export const ExtraRoutes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'icons',
        component: AppIconsComponent,
      },
      {
        path: 'sample-page',
        component: AppSamplePageComponent,
      },
      {
        path: 'liste-employee',
        component: EmployeeComponent,
      },
      {
        path: 'test-modal',
        component: ParentComponent,
      },
    ],
  },
];
